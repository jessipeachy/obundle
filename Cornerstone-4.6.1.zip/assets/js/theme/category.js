import utils, { hooks } from '@bigcommerce/stencil-utils';
import CatalogPage from './catalog';
import compareProducts from './global/compare-products';
import modalFactory, { showSuccessModal } from './global/modal';
import FacetedSearch from './common/faceted-search';

export default class Category extends CatalogPage {
    
    onReady() {
        let {
            cartId
        } = this.context;
        compareProducts(this.context.urls);
        this.alternateProductImage();
        this.addAllToCart(cartId);
        this.clearCart();

        if ($('#facetedSearch').length > 0) {
            this.initFacetedSearch();
        } else {
            this.onSortBySubmit = this.onSortBySubmit.bind(this);
            hooks.on('sortBy-submitted', this.onSortBySubmit);
        }
        // on load, check the cart quantity to show/hide the remove all items button
        const removeAllButton = $('#removeAllFromCart');
        let cartContentsQty = this.context.cartContentsQty;
        if(cartContentsQty){
            $(removeAllButton).show();
        } else {
            $(removeAllButton).hide();
        }
    }

    initFacetedSearch() {
        const $productListingContainer = $('#product-listing-container');
        const $facetedSearchContainer = $('#faceted-search-container');
        const productsPerPage = this.context.categoryProductsPerPage;
        const requestOptions = {
            config: {
                category: {
                    shop_by_price: true,
                    products: {
                        limit: productsPerPage,
                    },
                },
            },
            template: {
                productListing: 'category/product-listing',
                sidebar: 'category/sidebar',
            },
            showMore: 'category/show-more',
        };

        this.facetedSearch = new FacetedSearch(requestOptions, (content) => {
            $productListingContainer.html(content.productListing);
            $facetedSearchContainer.html(content.sidebar);

            $('body').triggerHandler('compareReset');

            $('html, body').animate({
                scrollTop: 0,
            }, 100);
        });
    }

    alternateProductImage() {
        const $productListingContainer = $('#product-listing-container');
        const $products = $($productListingContainer).find('.productGrid').children('.product');

        $.each($products, function( index, value ) {
            $(this).hover(function(){
                $(this).find('.card-img-container').addClass('alternate');  //Add the alternate class to the area is hovered
            }, function () {
                $(this).find('.card-img-container').removeClass('alternate');
            });
        });
        
    }
    
    addAllToCart(cartId){
        const categoryProducts = this.context.categoryProducts;

        const lineItems = $.map(categoryProducts, function(product, i) {
            return {quantity:1, productId:product.id};
        })

        function createCart(url, cartItems) {
            return fetch(url, {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json"},
                body: JSON.stringify(cartItems),
            })
            .then(response => response.json());
        };

        function addCartItem(url, cartId, cartItems) {
            return fetch(url + cartId + '/items', {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json"},
                body: JSON.stringify(cartItems),
            })
            .then(response => response.json());
       };

        function success(){
            const message = '<h3>Products Added</h3>';
            showSuccessModal(message);
            const removeAllButton = $('#removeAllFromCart');
            $(removeAllButton).show();
        }

        $('a#addAllToCart').click(function(evt) {
            evt.preventDefault();
            let addCartId;
            fetch('/api/storefront/cart', {
                credentials: 'include'
            }).then(function(response) {
                return response.json();
            }).then(function(myJson) {
                //if there is no cart already made, create a cart and add items
                if(myJson.length == 0){
                    createCart('/api/storefront/carts', {
                        "lineItems": lineItems})
                    .then(data => console.log(JSON.stringify(data.id)))
                    .catch(error => console.error(error));
                    success();
                } else {
                    addCartId = myJson[0].id;
                    addCartItem('/api/storefront/carts/', addCartId, {
                        "lineItems": lineItems})
                    .then(data => console.log(JSON.stringify(data)))
                    .catch(error => console.error(error));
                    success();
                }
            });
            
            });
    }
    
    clearCart(){
        let clearCartId;
        $('a#removeAllFromCart').click(function(evt){
            evt.preventDefault();
            
            fetch('/api/storefront/cart', {
                credentials: 'include'
            }).then(function(response) {
                return response.json();
            }).then(function(myJson) {
                clearCartId = myJson[0].id;
                const clearCartSettings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "/api/storefront/carts/" + clearCartId,
                    "method": "DELETE",
                    "headers": {}
                  }
                $.ajax(clearCartSettings).done(function (response) {
                    const message = '<h3>Products Removed</h3>';
                    showSuccessModal(message);
                    const removeAllButton = $('#removeAllFromCart');
                    $(removeAllButton).show();
                    $('.cart-quantity').toggleClass('countPill--positive');
                });
            });
            
        });
    }
        
}
